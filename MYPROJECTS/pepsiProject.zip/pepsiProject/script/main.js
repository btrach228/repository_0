function imgSlider(anything) {
    document.querySelector('.pepsi').src = anything;
}

function changebgColor(color) {
    const sec = document.querySelector('.sec');
    sec.style.background = color;

}